Amended from https://github.com/istio/istio/tree/master/samples/bookinfo/src/productpage.

Set details timeout to 45 sec (originally 3 sec).
